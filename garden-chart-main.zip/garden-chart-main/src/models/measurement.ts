export interface Measurement {
    date: Date
    value: number
}